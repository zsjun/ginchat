const config = require('@fantasticit/code-lint/lib/config/commitizen')();

// Here you can modify `config` as needed.
module.exports = config;
