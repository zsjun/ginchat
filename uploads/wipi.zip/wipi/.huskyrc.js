const config = require('@fantasticit/code-lint/lib/config/husky')();

// Here you can modify `config` as needed.
module.exports = config;
