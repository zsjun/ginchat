const config = require('@fantasticit/code-lint/lib/config/prettier')();

// Here you can modify `config` as needed.
module.exports = config;
