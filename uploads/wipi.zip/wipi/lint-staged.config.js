const config = require('@fantasticit/code-lint/lib/config/lint-stage')();

// Here you can modify `config` as needed.
module.exports = config;
