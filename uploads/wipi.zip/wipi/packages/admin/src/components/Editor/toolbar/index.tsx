import React from 'react';
import { Emoji } from './Emoji';
import { Iframe } from './Iframe';
import { Image } from './Image';
import { Video } from './Video';
import { File } from './File';

export const toolbar = [
  {
    label: '标题',
    content: () => (
      <svg viewBox="0 0 24 24" width="1em" height="1em">
        <path fillRule="evenodd" fill="currentColor" d="M15 13H9v6H7V5h2v6h6V5h2v14h-2v-6z"></path>
      </svg>
    ),
    getAction: (editor) => () => {
      editor.getAction('markdown.extension.editing.toggleHeadingUp').run(editor);
    },
  },
  {
    label: '加粗',
    content: () => (
      <svg viewBox="0 0 24 24" width="1em" height="1em">
        <path
          fill="currentColor"
          fillRule="evenodd"
          d="M13.5 19h-7V5h6a4 4 0 013.063 6.572A4 4 0 0113.5 19zm0-6h-5v4h5a2 2 0 100-4zm-1-2a2 2 0 100-4h-4v4h4z"
        ></path>
      </svg>
    ),
    getAction: (editor) => () => {
      editor.getAction('markdown.extension.editing.toggleBold').run(editor);
    },
  },
  {
    label: '斜体',
    content: () => (
      <svg viewBox="0 0 24 24" width="1em" height="1em">
        <path
          fill="currentColor"
          fillRule="evenodd"
          d="M10 5v2h2.623l-3.42 10H6v2h8.9v-2h-3.11l3.42-10H18V5z"
        ></path>
      </svg>
    ),
    getAction: (editor) => () => {
      editor.getAction('markdown.extension.editing.toggleItalic').run(editor);
    },
  },
  {
    label: '行内代码',
    content: () => (
      <svg viewBox="0 0 24 24" width="1em" height="1em">
        <path
          fillRule="evenodd"
          fill="currentColor"
          d="M8.5 6l-3 5h-2l1-5h4zm12 0l-3 5h-2l1-5h4z"
        ></path>
      </svg>
    ),
    getAction: (editor) => () => {
      editor.getAction('markdown.extension.editing.toggleCodeSpan').run(editor);
    },
  },
  {
    label: '删除线',
    content: () => (
      <svg viewBox="64 64 896 896" width="0.9em" height="0.9em">
        <path
          fill="currentColor"
          fillRule="evenodd"
          d="M952 474H569.9c-10-2-20.5-4-31.6-6-15.9-2.9-22.2-4.1-30.8-5.8-51.3-10-82.2-20-106.8-34.2-35.1-20.5-52.2-48.3-52.2-85.1 0-37 15.2-67.7 44-89 28.4-21 68.8-32.1 116.8-32.1 54.8 0 97.1 14.4 125.8 42.8 14.6 14.4 25.3 32.1 31.8 52.6 1.3 4.1 2.8 10 4.3 17.8.9 4.8 5.2 8.2 9.9 8.2h72.8c5.6 0 10.1-4.6 10.1-10.1v-1c-.7-6.8-1.3-12.1-2-16-7.3-43.5-28-81.7-59.7-110.3-44.4-40.5-109.7-61.8-188.7-61.8-72.3 0-137.4 18.1-183.3 50.9-25.6 18.4-45.4 41.2-58.6 67.7-13.5 27.1-20.3 58.4-20.3 92.9 0 29.5 5.7 54.5 17.3 76.5 8.3 15.7 19.6 29.5 34.1 42H72c-4.4 0-8 3.6-8 8v60c0 4.4 3.6 8 8 8h433.2c2.1.4 3.9.8 5.9 1.2 30.9 6.2 49.5 10.4 66.6 15.2 23 6.5 40.6 13.3 55.2 21.5 35.8 20.2 53.3 49.2 53.3 89 0 35.3-15.5 66.8-43.6 88.8-30.5 23.9-75.6 36.4-130.5 36.4-43.7 0-80.7-8.5-110.2-25-29.1-16.3-49.1-39.8-59.7-69.5-.8-2.2-1.7-5.2-2.7-9-1.2-4.4-5.3-7.5-9.7-7.5h-79.7c-5.6 0-10.1 4.6-10.1 10.1v1c.2 2.3.4 4.2.6 5.7 6.5 48.8 30.3 88.8 70.7 118.8 47.1 34.8 113.4 53.2 191.8 53.2 84.2 0 154.8-19.8 204.2-57.3 25-18.9 44.2-42.2 57.1-69 13-27.1 19.7-57.9 19.7-91.5 0-31.8-5.8-58.4-17.8-81.4-5.8-11.2-13.1-21.5-21.8-30.8H952c4.4 0 8-3.6 8-8v-60a8 8 0 0 0-8-7.9z"
        ></path>
      </svg>
    ),
    getAction: (editor) => () => {
      editor.getAction('markdown.extension.editing.toggleStrikethrough').run(editor);
    },
  },
  {
    label: '列表',
    content: () => (
      <svg viewBox="0 0 24 24" width="1em" height="1em">
        <path
          fill="currentColor"
          fillRule="evenodd"
          d="M2 17v-1h3v4H2v-1h2v-.5H3v-1h1V17H2zm1-9V5H2V4h2v4H3zm-1 3v-1h3v.9L3.2 13H5v1H2v-.9L3.8 11H2zm5-6h14v2H7V5zm0 14v-2h14v2H7zm0-6v-2h14v2H7z"
        ></path>
      </svg>
    ),
    getAction: (editor) => () => {
      editor.getAction('markdown.extension.editing.toggleList').run(editor);
    },
  },
  {
    label: '表情',
    content: ({ editor }) => <Emoji editor={editor} />,
    getAction: () => () => {
      return undefined;
    },
  },
  {
    label: '上传图片',
    content: ({ editor }) => <Image editor={editor} />,
    getAction: () => () => {
      return undefined;
    },
  },
  {
    label: '上传视频',
    content: ({ editor }) => <Video editor={editor} />,
    getAction: () => () => {
      return undefined;
    },
  },
  {
    label: '嵌入链接',
    content: ({ editor }) => <Iframe editor={editor} />,
    getAction: () => () => {
      return undefined;
    },
  },
  {
    label: '文件库',
    content: ({ editor }) => <File editor={editor} />,
    getAction: () => () => {
      return undefined;
    },
  },
];
