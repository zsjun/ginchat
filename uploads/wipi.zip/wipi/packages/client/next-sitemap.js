module.exports = {
  siteUrl: 'https://creation.shbwyz.com',
  generateRobotsTxt: true,
}
