const config = require('@fantasticit/code-lint/lib/config/stylelint')();

// Here you can modify `config` as needed.
module.exports = config;
